-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: gestion_plantas
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `historial_accesos`
--

DROP TABLE IF EXISTS `historial_accesos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historial_accesos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha_acceso` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `estado_sesion` enum('exitoso','fallido','cerrada') DEFAULT 'exitoso',
  `accion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_fecha` (`fecha_acceso`),
  KEY `idx_estado` (`estado_sesion`),
  CONSTRAINT `historial_accesos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial_accesos`
--

LOCK TABLES `historial_accesos` WRITE;
/*!40000 ALTER TABLE `historial_accesos` DISABLE KEYS */;
INSERT INTO `historial_accesos` VALUES (1,3,'2026-02-03 06:43:47','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','cerrada','logout'),(2,3,'2026-02-05 10:40:49','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','cerrada','logout'),(3,6,'2026-02-05 11:25:34','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','','registro_cliente'),(4,6,'2026-02-05 11:28:29','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','cerrada','logout'),(5,3,'2026-02-05 11:30:10','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','cerrada','logout'),(6,7,'2026-02-05 11:32:28','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','','registro_cliente'),(7,7,'2026-02-05 11:32:44','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','cerrada','logout'),(8,8,'2026-02-05 11:39:44','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','','registro_cliente'),(9,8,'2026-02-05 11:48:25','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','cerrada','logout'),(10,3,'2026-02-05 12:05:51','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','cerrada','logout'),(11,6,'2026-02-05 12:06:04','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','','login'),(12,6,'2026-02-06 12:53:04','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','cerrada','logout'),(13,3,'2026-02-06 12:53:57','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','','login'),(14,3,'2026-02-06 12:56:43','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','cerrada','logout'),(15,6,'2026-02-06 12:56:52','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','','login'),(16,6,'2026-02-06 13:38:34','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','cerrada','logout'),(17,3,'2026-02-06 13:39:07','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','','login'),(18,3,'2026-02-06 14:09:31','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','cerrada','logout'),(19,6,'2026-02-06 14:09:39','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','','login'),(20,3,'2026-02-06 16:18:00','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','cerrada','logout'),(21,6,'2026-02-06 16:18:18','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','','login'),(22,6,'2026-02-07 14:21:38','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','cerrada','logout'),(23,3,'2026-02-07 14:22:00','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','','login'),(24,3,'2026-02-08 04:29:10','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','','descargar_respaldo_1'),(25,3,'2026-02-08 17:15:29','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','','descargar_respaldo_2');
/*!40000 ALTER TABLE `historial_accesos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedido_detalle`
--

DROP TABLE IF EXISTS `pedido_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedido_detalle` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `id_pedido` int(11) NOT NULL,
  `id_planta` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL DEFAULT 1,
  `precio_en_compra` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_detalle`),
  KEY `id_pedido` (`id_pedido`),
  KEY `id_planta` (`id_planta`),
  CONSTRAINT `pedido_detalle_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`) ON DELETE CASCADE,
  CONSTRAINT `pedido_detalle_ibfk_2` FOREIGN KEY (`id_planta`) REFERENCES `plantas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido_detalle`
--

LOCK TABLES `pedido_detalle` WRITE;
/*!40000 ALTER TABLE `pedido_detalle` DISABLE KEYS */;
INSERT INTO `pedido_detalle` VALUES (1,1,4,1,300.00),(2,2,5,1,200.00);
/*!40000 ALTER TABLE `pedido_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `id_pago` int(11) DEFAULT NULL,
  `id_direccion` int(11) DEFAULT NULL,
  `estado_pedido` varchar(50) DEFAULT 'pendiente',
  `fecha_orden` datetime DEFAULT current_timestamp(),
  `costo_total` decimal(10,2) DEFAULT 0.00,
  PRIMARY KEY (`id_pedido`),
  KEY `idx_cliente` (`id_cliente`),
  KEY `idx_estado` (`estado_pedido`),
  KEY `idx_fecha` (`fecha_orden`),
  CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabla de pedidos de la tienda';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` VALUES (1,6,NULL,NULL,'pendiente','2026-02-06 12:45:13',336.00),(2,6,NULL,NULL,'enviado','2026-02-06 13:10:43',224.00);
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plantas`
--

DROP TABLE IF EXISTS `plantas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plantas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `especie` varchar(100) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `estado` enum('activa','inactiva','en_cuidado') DEFAULT 'activa',
  `ultimo_riego` datetime DEFAULT NULL,
  `proximo_riego` datetime DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `precio` decimal(10,2) DEFAULT 0.00,
  `descripcion` text DEFAULT NULL,
  `disponible_venta` tinyint(1) DEFAULT 0,
  `stock` int(11) DEFAULT 0,
  `categoria` varchar(50) DEFAULT NULL,
  `imagen_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_proximo_riego` (`proximo_riego`),
  CONSTRAINT `plantas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plantas`
--

LOCK TABLES `plantas` WRITE;
/*!40000 ALTER TABLE `plantas` DISABLE KEYS */;
INSERT INTO `plantas` VALUES (4,'Monstera Deliciosa','Monstera deliciosa','2026-02-02 04:32:41','activa',NULL,NULL,NULL,3,300.00,'Planta',1,9,'exterior',NULL),(5,'Suculenta Echeveria','Echeveria elegans','2026-02-02 04:32:41','activa',NULL,NULL,NULL,3,200.00,'Las Echeverias son suculentas populares por su belleza y facilidad de cultivo, con hojas carnosas dispuestas en rosetas y una amplia variedad de colores.',1,149,'suculenta',NULL),(6,'Lavanda','Lavandula angustifolia','2026-02-02 04:32:41','activa',NULL,NULL,NULL,3,300.00,'PLANTA',1,200,'aromática',NULL),(8,'suculenta','Monstera','2026-02-03 07:33:05','activa',NULL,NULL,NULL,3,0.00,NULL,0,0,NULL,NULL);
/*!40000 ALTER TABLE `plantas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registros_riego`
--

DROP TABLE IF EXISTS `registros_riego`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registros_riego` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_planta` int(11) NOT NULL,
  `fecha_riego` timestamp NOT NULL DEFAULT current_timestamp(),
  `cantidad_agua` decimal(5,2) NOT NULL,
  `tipo_riego` enum('normal','abundante','ligero') DEFAULT 'normal',
  `notas` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_planta` (`id_planta`),
  KEY `idx_fecha` (`fecha_riego`),
  CONSTRAINT `registros_riego_ibfk_1` FOREIGN KEY (`id_planta`) REFERENCES `plantas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registros_riego`
--

LOCK TABLES `registros_riego` WRITE;
/*!40000 ALTER TABLE `registros_riego` DISABLE KEYS */;
INSERT INTO `registros_riego` VALUES (4,4,'2026-02-03 03:21:00',500.00,'','ninguna');
/*!40000 ALTER TABLE `registros_riego` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respaldos`
--

DROP TABLE IF EXISTS `respaldos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `respaldos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_respaldo` timestamp NOT NULL DEFAULT current_timestamp(),
  `tipo_respaldo` enum('completo','diferencial','minima_modificacion') NOT NULL,
  `ruta_archivo` varchar(500) NOT NULL,
  `tamaño_mb` decimal(10,2) DEFAULT NULL,
  `realizado_por` varchar(100) DEFAULT NULL,
  `almacenamiento` varchar(50) DEFAULT NULL,
  `checksum` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fecha` (`fecha_respaldo`),
  KEY `idx_tipo` (`tipo_respaldo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respaldos`
--

LOCK TABLES `respaldos` WRITE;
/*!40000 ALTER TABLE `respaldos` DISABLE KEYS */;
INSERT INTO `respaldos` VALUES (1,'2026-02-08 04:24:46','completo','backups\\respaldo_completo_20260207_162446.sql.gz',0.00,'Administrador','local','bc0dd8b0014b6156869851f750d8ca6c95da9a770ded4f93158aef33ee3cbdad'),(2,'2026-02-08 04:27:54','completo','backups\\respaldo_completo_20260207_162753.sql.gz',0.00,'Administrador','local','a30368d7b1d9c0156d1cb8476ccb9f026684b752d4bff84487024fc1eb6abd59');
/*!40000 ALTER TABLE `respaldos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contrasenia_hash` varchar(255) NOT NULL,
  `rol` varchar(20) NOT NULL DEFAULT 'cliente',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `activo` tinyint(1) DEFAULT 1,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `estado` varchar(20) DEFAULT 'activo',
  `ciudad` varchar(100) DEFAULT NULL,
  `codigo_postal` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `correo` (`correo`),
  KEY `idx_correo` (`correo`),
  KEY `idx_rol` (`rol`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (3,'Administrador','admin@plantas.com','pbkdf2:sha256:1000000$CU99OgfK5dpXnqlm$085999541d68288111efc8d2f00593513b5e78956814243b7ca220322f1228e1','admin','2026-02-02 04:32:41',1,NULL,NULL,'activo',NULL,NULL),(4,'Juan Pérez','juan.perez@email.com','pbkdf2:sha256:1000000$randomhash$...','','2026-02-05 04:46:29',1,NULL,NULL,'activo',NULL,NULL),(5,'María García','maria.garcia@email.com','pbkdf2:sha256:1000000$randomhash$...','','2026-02-05 04:46:29',1,NULL,NULL,'activo',NULL,NULL),(6,'Emma','m@gmail.com','scrypt:32768:8:1$ZXljqRjX6vnw8uWK$f436c118ea3d546c4124c1646e44c469055aef92d58de16866d2e241dbf63f5ccbc5be0a4c20f106077a007f3d1de052ed914b7a74506f473a8ecc083dd0a022','cliente','2026-02-05 11:25:34',1,'6272772','Lerma','activo',NULL,NULL),(7,'Brau','brau@gmail.com','scrypt:32768:8:1$XPx1ffZ5yQHjV8qi$e8c32678518f8c222a26ef820f30c06e996131842b242e3657c5f4b8b1638524356efa330b49a08c8393a949413a5002d4e0b8c545dcff3249464c454c26f710','cliente','2026-02-05 11:32:28',1,'6272772','Lerma','activo',NULL,NULL),(8,'Rafael','rafa@gmail.com','scrypt:32768:8:1$l2xeZGVvVPP4spHq$2cbdcc1b78579d3cd06ba589fb282c96d913ed1887cc355b2664c3ab5d7d4fd73d740ea5c5aca8ada144faab70b0809e130ddff81777645d99a0b31af0d279bc','cliente','2026-02-05 11:39:44',1,'6272772','Lerma','activo',NULL,NULL),(9,'Cliente Demo','cliente@ejemplo.com','scrypt:32768:8:1$tNIHZkbj9gpufabj$1ab57b8abd8e6460931e762af625cb746b271eb47eb54ebf70026dae3a834fa6c64f9f7e3606a486d06980b00a8a47bef1937b1f2078414fb6067fa6bd755584','cliente','2026-02-06 17:23:18',1,NULL,NULL,'activo',NULL,NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-08  6:03:49
